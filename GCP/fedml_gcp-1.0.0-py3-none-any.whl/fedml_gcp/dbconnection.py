import json
from hdbcli import dbapi

from pkg_resources import resource_stream


class DbConnection:

    def __init__(self, package_name=None):
        if package_name is not None:
            self.config = json.load(
                resource_stream(package_name, 'config.json'))
        else:
            with open('config.json', 'r') as f:
                self.config = json.load(f)
        self.connection = self._get_connection()
        self.cursor = None

    def _get_connection(self):

        # optional arguments
        if "encrypt" not in self.config:
            self.config["encrypt"] = "true"
        if "sslValidateCertificate" not in self.config:
            self.config["sslValidateCertificate"] = "false"
        if "disableCloudRedirect" not in self.config:
            self.config["disableCloudRedirect"] = "true"
        if "communicationTimeout" not in self.config:
            self.config["communicationTimeout"] = "0"
        if "autocommit" not in self.config:
            self.config["autocommit"] = "true"
        if "sslUseDefaultTrustStore" not in self.config:
            self.config["sslUseDefaultTrustStore"] = "true"

        return dbapi.connect(
            address=self.config["address"],
            port=self.config["port"],
            user=self.config["user"],
            password=self.config["password"],
            schema=self.config["schema"],
            encrypt=self.config["encrypt"],
            sslValidateCertificate=self.config["sslValidateCertificate"],
            disableCloudRedirect=self.config["disableCloudRedirect"],
            communicationTimeout=self.config["communicationTimeout"],
            autocommit=self.config["autocommit"],
            sslUseDefaultTrustStore=self.config["sslUseDefaultTrustStore"]
        )

    # def _commit(self):
    #     self.connection.commit()

    # def _close(self):
    #     self.connection.close()

    # def _rollback(self):
    #     self.connection.rollback()

    # def _get_cursor(self):
    #     if self.connection.isconnected():
    #         self.cursor = self.connection.cursor()
    #     else:
    #         raise Exception("Failed to get cursor")

    def get_schema_views(self):
        if (self.connection.isconnected()):
            cursor = self.connection.cursor()
        else:
            self._get_connection()
            cursor = self.connection.cursor()
        try:
            query = "SELECT %s, %s  FROM %s WHERE %s = '%s' " % (
                "VIEW_NAME", "VIEW_TYPE", "VIEWS", "SCHEMA_NAME", self.config['schema'])
            cursor.execute(query)
            res = cursor.fetchall()
            column_headers = [i[0] for i in cursor.description]
        except Exception as e:
            print('error occured during query', e)
            self.connection.rollback()
        return res, column_headers

    def get_table_size(self, table_name):
        if (self.connection.isconnected()):
            cursor = self.connection.cursor()
        else:
            # raise connectionError('Database is not connected')
            self._get_connection()
            cursor = self.connection.cursor()
        schema = self.config['schema']
        sqlQuery = f'SELECT COUNT(*) FROM "{schema}"."{table_name}"'
        try:
            cursor.execute(sqlQuery)
            res = cursor.fetchall()
            return res
        except Exception as e:
            print('error occured during update, doing rollback', e)
            self.connection.rollback()

    def get_data_with_headers(self, table_name, size=1):
        if (self.connection.isconnected()):
            cursor = self.connection.cursor()
        else:
            self._get_connection()
            cursor = self.connection.cursor()
        rows = self.get_table_size(table_name)
        dataset_size = int(rows[0][0]*size)
        schema = self.config['schema']
        sqlQuery = f'SELECT TOP {str(dataset_size)} * FROM "{schema}"."{table_name}"'
        try:
            cursor.execute(sqlQuery)
            res = cursor.fetchall()
            column_headers = [i[0] for i in cursor.description]
            return res, column_headers
        except Exception as e:
            print('error occured during update, doing rollback', e)
            self.connection.rollback()

    def execute_query(self, query):
        if (self.connection.isconnected()):
            cursor = self.connection.cursor()
        else:
            self._get_connection()
            cursor = self.connection.cursor()
        try:
            cursor.execute(query)
            res = cursor.fetchall()
            column_headers = [i[0] for i in cursor.description]
            return res, column_headers
        except Exception as e:
            print('error occured during update, doing rollback', e)
            self.connection.rollback()
