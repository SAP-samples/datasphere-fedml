import os
import io
import numpy as np
import pandas as pd
import tarfile
try:
    from google.cloud import storage
    from oauth2client.client import GoogleCredentials
    from googleapiclient import discovery
    from googleapiclient import errors
    from google.cloud import bigquery
except:
    pass


class DwcGCP:
    def __init__(self,
                 project_name=None,
                 bucket_name=None):
        if project_name:
            self.project_name = project_name
        else:
            raise ValueError(
                'Error: Please iniate class with GCP project name')

        if bucket_name:
            self.bucket_name = bucket_name
        else:
            raise ValueError(
                'Error: Please iniate class with GCP Cloud Storage bucket name')

    def create_folder(self, bucket_name, destination_folder_name):
        storage_client = storage.Client()
        bucket = storage_client.get_bucket(bucket_name)
        blob = bucket.blob(destination_folder_name)

        blob.upload_from_string('')

        print('Created {} .'.format(
            destination_folder_name))

    def upload_blob(self, bucket_name, source_file_name, destination_blob_name):
        """Uploads a file to the bucket."""
        # The ID of your GCS bucket
        # bucket_name = "your-bucket-name"
        # The path to your file to upload
        # source_file_name = "local/path/to/file"
        # The ID of your GCS object
        # destination_blob_name = "storage-object-name"

        storage_client = storage.Client()
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(destination_blob_name)

        blob.upload_from_filename(source_file_name)

        print(
            "File {} uploaded to {}.".format(
                source_file_name, destination_blob_name
            )
        )

    def download_blob(self, bucket_name, source_blob_name, destination_file_name):

        storage_client = storage.Client()

        bucket = storage_client.bucket(bucket_name)

        blob = bucket.blob(source_blob_name)
        blob.download_to_filename(destination_file_name)

        print(
            "Downloaded storage object {} from bucket {} to local file {}.".format(
                source_blob_name, bucket_name, destination_file_name
            )
        )

    def create_bucket_class_location(self, bucket_name):
        """Create a new bucket in specific location with storage class"""
        # bucket_name = "your-new-bucket-name"

        storage_client = storage.Client()

        bucket = storage_client.bucket(bucket_name)
        bucket.storage_class = "STANDARD"
        new_bucket = storage_client.create_bucket(bucket, location="us")

        print(
            "Created bucket {} in {} with storage class {}".format(
                new_bucket.name, new_bucket.location, new_bucket.storage_class
            )
        )
        return new_bucket

    def make_tarfile(self, output_filename, source_dir):
        with tarfile.open(output_filename, "w:gz") as tar:
            tar.add(source_dir, arcname=os.path.basename(source_dir))

    def make_tar_bundle(self, output_filename='training.tar.gz', source_dir='training', destination='train/training.tar.gz'):

        self.make_tarfile(output_filename, source_dir)
        self.upload_blob(self.bucket_name, output_filename, destination)

    def train_model(self, jobId,
                    training_inputs):

        job_spec = {'jobId': jobId, 'trainingInput': training_inputs}
        project_id = 'projects/{}'.format(self.project_name)
        cloudml = discovery.build('ml', 'v1')
        request = cloudml.projects().jobs().create(body=job_spec,
                                                   parent=project_id)

        try:
            response = request.execute()
            print('Training Job Submitted Succesfully')
            print('Job status for {}.{}:'.format(self.project_name, jobId))
            print('    state : {}'.format(response['state']))
#             print('    consumedMLUnits : {}'.format(
#             response['trainingOutput']['consumedMLUnits']))

            # You can put your code for handling success (if any) here.

        except errors.HttpError as err:
            # Do whatever error response is appropriate for your application.
            # For this example, just send some text to the logs.
            # You need to import logging for this to work.
            print('There was an error creating the training job.'
                  ' Check the details:')
            print(err._get_reason())

    def deploy(self, model_name, model_location,  version, region, prediction_location='', custom_predict=None, module_name=None, onlinePredictionLogging=False, onlinePredictionConsoleLogging=False):

        project_id = 'projects/{}'.format(self.project_name)

        model_request_dict = {'name': model_name, "regions": [
            region], "onlinePredictionLogging": onlinePredictionLogging, "onlinePredictionConsoleLogging": onlinePredictionConsoleLogging}
#         model_request_dict = {'name': model_name}

        ml = discovery.build('ml', 'v1')

        endpoint_id = region

        model_request = ml.projects().models().create(
            parent=project_id, body=model_request_dict)

        try:
            response = model_request.execute()
            print(response)
        except errors.HttpError as err:
            # Something went wrong, print out some information.
            print('There was an error creating the model. Check the details:')
            print(err._get_reason())

        model_path = self.project_name + '/models/' + model_name
        model_id = 'projects/{}'.format(model_path)

        deployment_uri = 'gs://' + self.bucket_name + model_location

        version_create_request = {
            "name": 'version',
            "description": '',
            "isDefault": False,
            "deploymentUri": deployment_uri,
            "framework": 'SCIKIT_LEARN',
            'runtimeVersion': '2.5'
        }

        if custom_predict and module_name:
            package_uri = 'gs://' + self.bucket_name + \
                '/' + prediction_location + custom_predict

            version_create_request = {
                "name": 'version',
                "description": '',
                "isDefault": False,
                "deploymentUri": deployment_uri,
                "packageUris": [package_uri],
                #                 "framework": 'SCIKIT_LEARN',
                'runtimeVersion': '2.5',
                "predictionClass": module_name
            }

        version_request = ml.projects().models().versions().create(
            parent=model_id, body=version_create_request)

        try:
            response = version_request.execute()
            print(response)
        except errors.HttpError as err:
            # Something went wrong, print out some information.
            print('There was an error creating the model. Check the details:')
            print(err._get_reason())

    def enable_logging(self, model_name, version, samplingPercentage, datasetName, tableName, createDataset=False, createTable=False):

        model_id = 'projects/' + self.project_name + \
            '/models/' + model_name + '/versions/' + version

        ml = discovery.build('ml', 'v1')

        if createTable:
            client = bigquery.Client()

            if createDataset:
                dataset_id = self.project_name + "." + datasetName
                dataset = bigquery.Dataset(dataset_id)
                dataset.location = "US"
                dataset = client.create_dataset(dataset, timeout=30)
                print("Created dataset {}.{}".format(
                    client.project, dataset.dataset_id))

            table_id = self.project_name + "." + datasetName + "." + tableName

            schema = [
                bigquery.SchemaField("model", "STRING", mode="REQUIRED"),
                bigquery.SchemaField(
                    "model_version", "STRING", mode="REQUIRED"),
                bigquery.SchemaField("time", "TIMESTAMP", mode="REQUIRED"),
                bigquery.SchemaField("raw_data", "STRING", mode="REQUIRED"),
                bigquery.SchemaField(
                    "raw_prediction", "STRING", mode="NULLABLE"),
                bigquery.SchemaField("groundtruth", "STRING", mode="NULLABLE")

            ]

            table = bigquery.Table(table_id, schema=schema)
            table = client.create_table(table)  # Make an API request.
            print(
                "Created table {}.{}.{}".format(
                    table.project, table.dataset_id, table.table_id)
            )

        logging = {
            "samplingPercentage": samplingPercentage,
            "bigqueryTableName": tableName
        }

        version_patch_request = {

            "requestLoggingConfig": logging
        }

        version_request = ml.projects().models().versions().patch(
            name=model_id, updateMask=version_patch_request)

        try:
            response = version_request.execute()
            print(response)
        except errors.HttpError as err:
            # Something went wrong, print out some information.
            print('There was an error creating the model. Check the details:')
            print(err._get_reason())
