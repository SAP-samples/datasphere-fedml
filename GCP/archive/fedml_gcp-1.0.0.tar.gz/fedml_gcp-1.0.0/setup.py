#!/usr/bin/env python

import setuptools
setuptools.setup(
    name="fedml_gcp",
    version="1.0.0",
    author="Jack Seeburger",
    author_email="jack.seeburger@sap.com",
    description="Federated ML Package for GCP",
    # long_description=long_description,
    # long_description_content_type="text/markdown",
    # url="https://github.com/pypa/sampleproject",
    # project_urls={
    #     "Bug Tracker": "https://github.com/pypa/sampleproject/issues",
    # },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    install_requires=[
        "hdbcli",
        "google"
        # "numpy",
        # "pandas"
    ],
    package_dir={"": "src"},
    packages=setuptools.find_packages(where="src"),
    python_requires=">=3",
    # package_data={'fedml_gcp': ['internal_config.json']}
)
