import boto3, os
import io
import numpy as np
import pandas as pd
# from dbconnection import DbConnection
# from hdbcli import dbapi
import shutil
import datetime
import botocore
try:
    import sagemaker
    from sagemaker import get_execution_role
    from sagemaker.sklearn.estimator import SKLearn
except:
    pass

class DwcSagemaker:
    def __init__(self,  
                 prefix=None, 
                 bucket_name=None):
        self.region = boto3.session.Session().region_name
        try:
            self.role = get_execution_role()
            self.prefix = prefix
            bucket_name = self._get_bucket_name(bucket_name)
            self.bucket_name = bucket_name
            s3 = boto3.resource('s3')
            try:
                if self.region == 'us-east-1':
                    s3.create_bucket(Bucket=bucket_name)
                else:
                    s3.create_bucket(Bucket=bucket_name, CreateBucketConfiguration={'LocationConstraint': self.region})
            except Exception as e:
                print('S3 error: ', e)
        except Exception as e:
            pass

    def _get_bucket_name(self, bucket_name):
        if bucket_name:
            return bucket_name
        else:
            return 'federatedml-' + datetime.datetime.now().strftime('%Y-%m-%d-%H-%M-%S')


    # def load_dwc_dataset(self, table, size=1):
    #     db = DbConnection()
    #     res, column_headers = db.get_data_with_headers(table, size)
    #     return pd.DataFrame(res, columns=column_headers)
    
    # def execute_query(self, query):
    #     db = DbConnection()
    #     res, column_headers = db.execute_query(query)
    #     return pd.DataFrame(res, columns=column_headers)

#     def load_sagemaker_model(self, algorithm):
#         return sagemaker.image_uris.retrieve(algorithm, self.region, "latest"

    def _upload_dataframe(self, data, content_type='csv', which='train', s3distributionType=None):
        data.to_csv(which+'.csv', index=False, header=False)
        boto3.Session().resource('s3').Bucket(self.bucket_name).Object(os.path.join(self.prefix, '{}/{}.csv'.format(which, which))).upload_file(which+'.csv')     
        s3_input = sagemaker.inputs.TrainingInput(s3_data='s3://{}/{}/{}'.format(self.bucket_name, self.prefix, which), content_type=content_type, distribution=s3distributionType)
        return s3_input
    
    def _upload_protobuf(self, data, which='train', s3distributionType=None):
        boto3.Session().resource('s3').Bucket(self.bucket_name).Object(os.path.join(self.prefix, '{}/{}.protobuf'.format(which, which))).upload_fileobj(data)
        s3_input_path = sagemaker.inputs.TrainingInput(s3_data='s3://{}/{}/{}'.format(self.bucket_name, self.prefix, which), distribution=s3distributionType)
        #'s3://{}/{}/{}'.format(self.bucket_name, self.prefix, which)
        return s3_input_path
    
    def _upload_file(self, data_file, which='train', s3distributionType=None):
        boto3.Session().resource('s3').Bucket(self.bucket_name).Object(os.path.join(self.prefix, '{}/{}'.format(which, data_file))).upload_file(data_file)
        s3_input_path = sagemaker.inputs.TrainingInput(s3_data='s3://{}/{}/{}'.format(self.bucket_name, self.prefix, which), distribution=s3distributionType)
        # s3_input_path = 's3://{}/{}/{}'.format(self.bucket_name, self.prefix, which)
        return s3_input_path
    
    def _upload_data(self, data, content_type=None, which='train', s3distributionType=None):
        if isinstance(data, pd.core.frame.DataFrame):
            s3_input_path = self._upload_dataframe(data, content_type=content_type, which=which, s3distributionType=s3distributionType)
            
        elif isinstance(data, io.BytesIO):
            s3_input_path = self._upload_protobuf(data, which=which, s3distributionType=s3distributionType)
            
        elif isinstance(data, str) and (data.endswith(('.json', '.json.gz', '.csv', '.txt'))):
            s3_input_path = self._upload_file(data, which=which)
            
        return s3_input_path

    def train_sagemaker_model(self, 
                              train_data,
                              framework,
                              framework_version='latest',
                              train_content_type='csv',
                              test_content_type='csv',
                              instance_count=1,
                              instance_type=None,
                              base_job_name=None,
                              hyperparameters=None,
                              test_data=None,
                              s3distributionTypeTrain=None,
                              s3distributionTypeTest=None):
        
        model_container = sagemaker.image_uris.retrieve(framework, self.region, framework_version)
        
        print('{} framework loaded'.format(framework))
        
        s3_input_train = self._upload_data(train_data, train_content_type,s3distributionType=s3distributionTypeTrain)
        
        print('Training data uploaded')
        
        if test_data is not None:
            s3_input_test = self._upload_data(test_data, test_content_type, which='test', s3distributionType=s3distributionTypeTest)
                
            print('Test data uploaded')

        sess = sagemaker.Session()
        clf = sagemaker.estimator.Estimator(model_container, 
                                            self.role, 
                                            instance_count=instance_count, 
                                            instance_type=instance_type, 
                                            output_path='s3://{}/{}/output'.format(self.bucket_name, self.prefix),
                                            base_job_name=base_job_name,
                                            sagemaker_session=sess)

        clf.set_hyperparameters(**hyperparameters)
        
        if test_data is not None:
            clf.fit({'train': s3_input_train, 'test': s3_input_test})            
        else:
            clf.fit({'train': s3_input_train})
        
        return clf
    
    def train_sklearn_model(self, 
                            train_data=None, 
                            test_data=None, 
                            content_type=None,
                            train_script=None, 
                            instance_count=1,
                            instance_type=None, 
                            base_job_name=None,
                            hyperparameters=None,
                            wait=False,
                            logs='All',
                            download_output=False):
        
        FRAMEWORK_VERSION = "0.23-1"

        s3_input_train = self._upload_data(train_data, content_type)
        print('Training data uploaded')
    
        if test_data is not None:
            s3_input_test = self._upload_data(test_data, content_type, which='test')
            print('Test data uploaded')
    
        
        sklearn_estimator = SKLearn(entry_point=train_script,
                                    role=self.role,
                                    instance_count=instance_count,
                                    instance_type=instance_type,
                                    framework_version=FRAMEWORK_VERSION,
                                    base_job_name=base_job_name,
                                    hyperparameters=hyperparameters)
        
        if test_data is not None:
            sklearn_estimator.fit({'train': s3_input_train, 'test': s3_input_test}, 
                wait=wait,
                logs=logs)
        else:
            sklearn_estimator.fit({'train': s3_input_train},
                wait=wait,
                logs=logs)

        if download_output:
            sklearn_estimator.latest_training_job.wait(logs='None')
            sm_boto3 = boto3.client('sagemaker')
            artifact = sm_boto3.describe_training_job(TrainingJobName=sklearn_estimator.latest_training_job.name)
            model_bucket = artifact['OutputDataConfig']['S3OutputPath'].rsplit('//')[-1][:-1]
            output_file = os.path.join(artifact['TrainingJobName'], 'output/output.tar.gz')
            try:
                boto3.Session().resource('s3').Bucket(model_bucket).download_file(output_file, os.path.basename(output_file))
                local_output_dir =  'output-' + datetime.datetime.now().strftime('%Y-%m-%d-%H-%M-%S')
                shutil.unpack_archive(os.path.basename(output_file), local_output_dir)
                print('Output files saved in ' + local_output_dir)
            except botocore.exceptions.ClientError as e:
                print('Output files could not be downloaded')

        return sklearn_estimator
    
    def cleanup_resources(self):
        bucket_to_delete = boto3.resource('s3').Bucket(self.bucket_name)
        bucket_to_delete.objects.all().delete()

    def deploy(self, 
               clf, 
               initial_instance_count,
               instance_type):
        predictor = clf.deploy(initial_instance_count=initial_instance_count, instance_type=instance_type)
        self.cleanup_resources()
        return predictor.endpoint_name
        
    def predict(self, endpoint_name, test_data):
        client = boto3.client('sagemaker-runtime', region_name=self.region)
        response = client.invoke_endpoint(EndpointName=endpoint_name,
                                          Body=test_data.to_csv(header=False, index=False).encode('utf-8'),
                                          ContentType='text/csv')
        return response['Body'].read().decode()